# Hello World Door

A simple example TypeScript door for AmiExpress-Web BBS.

## Features
- Displays welcome message
- Shows current date/time
- Demonstrates basic door structure

## Installation
Upload the ZIP archive through the Door Manager in the BBS.

## Usage
Run the door from the main menu or door list.
