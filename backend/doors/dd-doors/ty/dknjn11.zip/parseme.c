#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *parse_string(char *src, char *search, char *repl, char *fillch);

/********************************************************************** 
* char *parse_string(char *src, char *search, char *repl, char *fillch)
*
* Let us parse this baby =)
* Maybe there is such a function in C already, but humm I don't know
*
* char *src	: The string to parse
* char *search	: What @TAG@ to search for
* char *repl	: What to replace *search with
* char fillch   : What char to fill in format with
*
* returns	: A pointer to the parsed and token replaced string
*
* FEEL FREE TO OPTIMIZE MY ROUTINE AND SEND IT BACK TO ME =]
* (rezine@criminology.de)
*
* TAG FORMAT CAN BE LIKE THIS
* 
* @TAGNAME:<JUSTIFY><FIELDLEN>@
*
* Example :
*
* @USERNAME:L30@
*
* Would left-justify the variable you fill in for USERNAME, and - say if
* your variable would only be 20 chars long - fills the rest with 'fillch'
*
* Valid JUSTIFY identifiers are :
*
* L for left justify
* R for right justify   
* C for center justify   <-- Not implemented yet =\
*
* If the variable you supply is longer as the fieldlen, your variable
* will NOT be cutted!!! So take care of what you supply, else format
* will break up.
*
* Feel free to use this function in your own programs and to modify it
* to fit your needs. A credit would be nice, though =]
***********************************************************************/
char *parse_string(char *src, char *search, char *repl, char *fillch)
{
int i=0,j=0,k=0,l=0,m;
char buf[1024],buff[1024];
char src_buf[1024];
char justify[5];
char jlen_buf[5];
int jlen,repl_len;
int add;

    /***********************************************************
    * Uh yeah, now it's getting a little cryptic =]]]
    ***********************************************************/
    while(1)
    {
	if(src[i]=='@')
	{
	    i++;
	    while(src[i]!='@')
	    {
	        if(src[i]==':')
		{
		    l=0;
		    i++;
		    justify[0]=src[i];
		    justify[1]=0;
		    while(1)
		    {
			i++;
			if(src[i]!='@')
			{
			    jlen_buf[l]=src[i];
			    l++;
			    jlen_buf[l]=0;
			}
			else
			{
			    break;
			}
		    }
		}
		else
		{
		    buf[j]=src[i];
		    j++;
		    i++;
		}
		if(src[i]=='@')
		{
		    buf[j]=0;
		    j=0;
		    break;
		}
	    }	
    	    if (strcmp(buf,search)==0)
	    {
		jlen=atoi(jlen_buf);
		repl_len=strlen(repl);
		if(justify)
		{
		    strcpy(buff,"");
		    if(strcmp(justify,"C"))
		    {
			for(m=repl_len;m<=jlen;m++)
			{
			    strcat(buff,fillch);
			}
		    }
		    else if(!strcmp(justify,"C"))
		    {
			for(m=repl_len;m<=jlen/2;m++)
			{
			    strcat(buff,fillch);
			}
		    }	
		    
		    if(!strcmp(justify,"L"))
		    {
			strcat(src_buf,repl);
			strcat(src_buf,buff);
		    }
		    else if(!strcmp(justify,"R"))
		    {
			strcat(src_buf,buff);
			strcat(src_buf,repl);
		    }
		    else if(!strcmp(justify,"C"))
		    {
			strcat(src_buf,buff);
			strcat(src_buf,repl);
			strcat(src_buf,buff);
		    }		
		    k=k+strlen(repl)+strlen(buff);
		}
	    }
	    else
	    {
		add=2;
		strcat(src_buf,"@");
		strcat(src_buf,buf);
		if(justify)
		{
		    add++;
		    strcat(src_buf,":");
		    add++;
		    strcat(src_buf,justify);
		    add=add+strlen(jlen_buf);
		    strcat(src_buf,jlen_buf);
		}
		strcat(src_buf,"@");
		k=k+strlen(buf)+add;
	    }
	}
	else
	{
	    src_buf[k]=src[i];
	    k++;
	    src_buf[k]=0;
	}
	i++;
	if(i==strlen(src)) break;
    }
    src_buf[k]=0;
    return(src_buf);
}