#define MAXUSERS 100
#define MAXLISTS 100
#define FSEDCMD "EDTEST"

char *stripcrlf(char *string)
{
int i;
int len;
    len=strlen(string);
    for(i=len-3;i<=len;i++)
    {
	if(string[i]==10) 
	{
	    string[i]=0;
	    break;
	}
    }
    return(string);
}