# Make sure to monitor your client and keep it updated as new
# versions are released. The server will now enforce version
# control and a version deemed too old will not be able to
# connect.

# Add the name of your BBS here.
# This will show in the /BBSES command
bbsname     = "Unconfigured BBS"

# Add details for your BBS here.
# This will show with the new /INFO command
# Max string is maximum 64 printed characters and 128 total
# PIPE codes are allowed
info_web    = "Unconfigured BBS"
info_telnet = "Unconfigured BBS"
info_ssh    = "Unconfigured BBS"
info_sysop  = "Unconfigured BBS"
info_desc   = "Unconfigured BBS"

