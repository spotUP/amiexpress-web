/*
                 __,,---,__ _    __,,--, __ _
                 |  ___/---,,__,-|  ___//___,,----,______,,---,__ __ _
       _ __ _____|  \_   _  \_   | \\_  __  \_  __   (___)      \ tdmHz
           \\_  __  _|   ____|_ \_/  |  \|   |  \|   | \_   |__//_
            _|  \|  \__  |/  _// |   |_  |  _|   |  _|  _|   |'  _/'' '
     ==== = \\     ___// '  _|   |____/' ' \\____| \\___\__      | = ====
   - -- ---- \____// \_____/__,,-'   \\__,,---'  |____/   \\_,,--' --- -- -
             daydream bbs : oneliners door v1.o by claywar!demonic                                                                       
    
    So simple, its almost stupid, no?  Well, some people like this sort of
    thing, so why not write it?  Oneliners door written and tested with
    daydream v2.06, if you have problems with an older version contact me
    and I'll provide a fix.
    
    Ok, I finished this and it looks like shit with the header/bottom that
    I put in it because I HAVE NO OS ASCII SKILL.  I'm not even going to try,
    so here's a little opportunity for you artists out there in bbs modding
    groups to write mods for this. (hint? yeah, it is)
*/


#include <stdio.h>
#include "ddlib.h"

#define HCHAR	"+"

int tot_liners() {
  FILE *liners;
  char fname[40], buf[256];
  int cnt=0;
  
  *fname = '\0';
  sprintf(fname, "%s/data/oneliners.dat", getenv("DAYDREAM"));
  if (!(liners = fopen(fname, "r")))
    return 0;
 
  
  while (!feof(liners)) {
    fgets(buf, 70, liners);
    if (buf) 
      cnt++;
  }
  
  return cnt;
} 

void add_oneliner(struct dif *d, int nl) {
  FILE *liners, *newfl;
  char fname[40], nfname[40], liner[70], buf[256];
  int cnt=0, tlines=tot_liners();
    
  *liner = '\0';
  
  dd_sendstring(d, "\e[34mEnter oneliner in space below\e[36m:\n");
  dd_sendstring(d, "\e[35m> \e[36m");
  dd_prompt(d, liner, 68, 0);
  
  if (!liner || !strcmp(liner,"")) {
    dd_sendstring(d, "\e[36mEmpty oneliners not allowed.\n\e[0m");
    return;
  }

  *fname = '\0';
  sprintf(fname, "%s/data/oneliners.dat", getenv("DAYDREAM"));
  if (!(liners = fopen(fname, "r"))) {
    dd_sendstring(d, "\e[36mUnable to open oneliners.dat, inform op!\e[0m\n");
    dd_pause(d);
    return;
  }
  
  *nfname='\0';
  sprintf(nfname, "%s/data/oneliners.new", getenv("DAYDREAM"));
  if (!(newfl = fopen(nfname, "w+"))) {
    dd_sendstring(d, "\e[36mUnable to create oneliners.new, inform op!\e[0m\n");
    dd_pause(d);
    return;
  }
  
  cnt = 0;
  while (!feof(liners) && (cnt < nl)) {
    *buf = '\0';
    
    fgets(buf,70,liners);
    if (buf && (cnt || (tlines <= nl))) 
      fprintf(newfl, "%s", buf);
    cnt++;
  }
    
  fprintf(newfl, "%s\n", liner);

  fclose(liners);
  fflush(newfl);
  fclose(newfl);
  unlink(fname);
  rename(nfname, fname);
}
  
    

void list_oneliners(struct dif *d, int nl) {
  FILE *liners;
  char fname[40];
  int cnt=0;
  char buf[256], format[256];
  
  *fname = '\0';
  sprintf(fname, "%s/data/oneliners.dat", getenv("DAYDREAM"));
  if (!(liners = fopen(fname, "r"))) {
    dd_sendstring(d, "\e[36mUnable to open oneliners.dat, inform op!\e[0m\n");
    dd_pause(d);
    return;
  }
  
  while (!feof(liners) && cnt < nl) {
    *buf = '\0';
    
    fgets(buf,70,liners);
    if (buf && !feof(liners)) {
      *format = '\0';
      sprintf(format, "\e[36m%s \e[32m%s\e[0m", HCHAR, buf);
      dd_sendstring(d, format);
    }
    cnt++;
  }
  
  fclose(liners);
  
}
  

void main(int argc, char *argv[]) {
  struct dif *d;
  int numlines=0;
  char buf[256];
  int what=0;
  
  if (argc==1) {
    printf("This is a DayDream door.\n");
    exit(1);
  }
  
  d = dd_initdoor(argv[1]);
  
  if (d == 0) {
    printf("Couldn't find socket!\n");
    exit(1);
  }
  
  if (!argv[2]) {
    dd_sendstring(d, "\e[36mNumber of oneliners to list was not specified!\e[0m\n");
    dd_pause(d);
    dd_close(d);
    exit(1);
  } else numlines=atoi(argv[2]);
  
  dd_changestatus(d, "Listing oneliners.");
  
  dd_typefile(d, "onelntop", TYPE_MAKE|TYPE_WARN);
  
  list_oneliners(d, numlines);

  dd_typefile(d, "onelnbot", TYPE_MAKE|TYPE_WARN);
  
  *buf='\0';
  sprintf(buf, "\n\e[33mDo you wish to add a oneliner? \e[0m(\e[32myes\e[0m/\e[32mNo\e[0m) \e[36m:\e[0m ");
  dd_sendstring(d, buf);
  what = dd_hotkey(d, HOT_NOYES);
  
  switch (what) {
    case 1:
      add_oneliner(d, numlines);
      break;
    default:
  }
  
  dd_close(d);

}
  