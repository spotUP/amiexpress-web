
   ****  THIS IS PREVIEW-BETA DO NOT SPREAD, JUST FOR TESTING PURPOSES ****

    This is preview-beta (or something) of The Cleaner v1.1b rev1.
    It works flawlessly in my RedHat v5.1 linux.


			    HOW IT WORKS?

    run the software by 'cleaner infile outfile /P'
    
    the infile is for example directory.001 filelist, the outfile is some
    filename you'll give and there the cleaned filelist will be written.
    after you have cleaned the filelist, just copy the new 'outfile' list over
    the old DayDream filelist in your BBS setup. Do not care of the .cfg and 
    .dat files in this dir, they are some old stuff and will be removed soon.

    Please notice that the parameter needs to be /P and not /p :)
    
    I have included my example filelist in this packet 'dir.001' file, try it
    out with command 'cleaner dir.001 new.001 /P' to see the power of Cleaner!    
    
Snake Man, PMC 1999.