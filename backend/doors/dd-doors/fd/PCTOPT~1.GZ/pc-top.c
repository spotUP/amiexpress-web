/*
	Rah. PC-Top door for daydream.
	
*/

#include <ddlib.h>
#include <dd.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

struct dif *d;

void die(void);

int main(int argc, char *argv[])
{
	char buf[1024];
	int i;
	int cfgfd;
	char *cptr;
	FILE *wu, *tang;
	struct DayDream_MainConfig cfg;
	int fod;
	struct tm *tm;
	time_t t;
	struct userbase elite;
	char name[80];
	
	if (argc==2) {
		printf("This program requires MS Windows!\n");
		exit(1);
	}
	d=dd_initdoor(argv[1]);
	if (d==0) {
		printf("Couldn't find socket!\n");
		exit(1);
	}
	atexit(die);

	dd_getstrval(d,name,USER_HANDLE);
	if (strcasecmp(name,"SNAKE MAN")) {
		dd_sendstring(d,"You are not k��rme enuff to run this door!\n");
		exit(0);
	}
	sprintf(buf,"%s/data/daydream.dat",getenv("DAYDREAM"));
	fod=open(buf,O_RDONLY);
	if (fod < 0) exit(0);
	read(fod,&cfg,sizeof(struct DayDream_MainConfig));
	close(fod);
	
	strupr(cfg.CFG_SYSOPNAME);
	sprintf(buf,"/tmp/%s.TOP",argv[2]);
	tang=fopen(buf,"w");

	sprintf(buf,"/tmp/%s.DAT",argv[2]);
	wu=fopen(buf,"w");

	t=time(0);
	tm=localtime(&t);
	
	fprintf(tang,"%s\r\n%-2.2d.%-2.2d.%-4.4d\r\n",argv[2],tm->tm_mday,tm->tm_mon+1,1900+tm->tm_year);
	fprintf(wu,"%s\r\n%-2.2d.%-2.2d.%-4.4d\r\n",argv[2],tm->tm_mday,tm->tm_mon+1,1900+tm->tm_year);

	sprintf(buf,"%s/data/userbase.dat",getenv("DAYDREAM"));
	
	fod=open(buf,O_RDONLY);
	if (fod < 0) {
		exit(0);
	}
	lseek(fod,sizeof(struct userbase),SEEK_CUR);
	while(read(fod,&elite,sizeof(struct userbase)))
	{
		strupr(&elite.user_handle);
		fprintf(wu,"%s\r\n%Lu\r\n",elite.user_handle,elite.user_ulbytes);
		fprintf(tang,"%s\r\n%Lu\r\n%d\r\n%d\r\n",elite.user_handle,elite.user_dlbytes,elite.user_pvtmessages+elite.user_pubmessages,elite.user_connections);
	}
	close(fod);
	fclose(wu); fclose(tang);
	sprintf(buf,"/tmp/pctopkala%s",argv[1]);
	wu=fopen(buf,"w");
	fprintf(wu,"/tmp/%s.TOP\n",argv[2]);
	fprintf(wu,"/tmp/%s.DAT\n",argv[2]);
	fclose(wu);
	dd_sendfiles(d,buf);
	
}

int strupr (char *strh)
{
	while (*strh)
	{
		*strh++=toupper(*strh);
	}
}

void die(void)
{

	dd_close(d);	
}