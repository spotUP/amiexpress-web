/*
                 __,,---,__ _    __,,--, __ _
                 |  ___/---,,__,-|  ___//___,,----,______,,---,__ __ _
       _ __ _____|  \_   _  \_   | \\_  __  \_  __   (___)      \ tdmHz
           \\_  __  _|   ____|_ \_/  |  \|   |  \|   | \_   |__//_
            _|  \|  \__  |/  _// |   |_  |  _|   |  _|  _|   |'  _/'' '
     ==== = \\     ___// '  _|   |____/' ' \\____| \\___\__      | = ====
   - -- ---- \____// \_____/__,,-'   \\__,,---'  |____/   \\_,,--' --- -- -
         daydream bbs : message base list door v1.o by claywar!demonic                                                                       
    
    So simple, its almost stupid, no?  Well, some people like this sort of
    thing, so why not write it?
*/


#include <stdio.h>
#include "ddlib.h"

void main(int argc, char *argv[]) {
  struct dif *d;
  struct DayDream_Conference *confs;
  struct DayDream_MsgBase *bd;
  char buf[256];
  int bcnt;

  *buf='\0';    

  if (argc==1) {
    printf("This is a DayDream door.\n");
    exit(1);
  }
  
  d = dd_initdoor(argv[1]);
  
  if (d == 0) {
    printf("Couldn't find socket!\n");
    exit(1);
  }
  
  dd_changestatus(d, "Listing msg bases.");
    
  confs = (struct DayDream_Conference *)dd_getconf(dd_getintval(d, USER_JOINCONFERENCE));
  if (!confs) {
    dd_sendstring(d, "\e[36mError opening conference data!\e[0m\n");
    dd_pause(d);
    dd_close(d);
  }
  
  bcnt = confs->CONF_MSGBASES;
  sprintf(buf,"\e[36mmessage bases for \e[35m%s\e[0m:\n",
            confs->CONF_NAME);
            
  dd_sendstring(d, buf);
  dd_sendstring(d, "\e[35m##   name\e[0m\n");
  dd_sendstring(d, "\e[34m----------------------------------------\e[0m\n");

  (struct DayDream_Conference *)bd=confs+1;
  for (bcnt=confs->CONF_MSGBASES;bcnt;bcnt--,bd++) {
    *buf='\0';
    sprintf(buf, "\e[33m%2d   \e[32m%s\e[0m\n", bd->MSGBASE_NUMBER, bd->MSGBASE_NAME);
    dd_sendstring(d,buf);
  }
  
  dd_close(d);

}
  