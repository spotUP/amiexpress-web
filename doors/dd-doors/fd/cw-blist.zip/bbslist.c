/*
                 __,,---,__ _    __,,--, __ _
                 |  ___/---,,__,-|  ___//___,,----,______,,---,__ __ _
       _ __ _____|  \_   _  \_   | \\_  __  \_  __   (___)      \ tdmHz
           \\_  __  _|   ____|_ \_/  |  \|   |  \|   | \_   |__//_
            _|  \|  \__  |/  _// |   |_  |  _|   |  _|  _|   |'  _/'' '
     ==== = \\     ___// '  _|   |____/' ' \\____| \\___\__      | = ====
   - -- ---- \____// \_____/__,,-'   \\__,,---'  |____/   \\_,,--' --- -- -
              daydream bbs : bbs list door v1.o by claywar!demonic                                                                       
    
    Ok, this thing was a major bitch to write.  The way its layed out in the
    data file allows the op to edit it easily and still be 100% compat with
    the functions contain.  SPACING IS IMPORTANT.  So if you edit the file by
    hand, remember to keep 29, 28, and 14 spaces clear (thats the fieldlen).
    cw!
*/


#include <stdio.h>
#include "ddlib.h"

void strip_string(char *buffer) {
  register char *ptr, *str;
  
  ptr = buffer;
  str = ptr;

  while((*str = *ptr))
  { str++;
    ptr++;
    if (*ptr == '\r')
      ptr++;
  }
}
                          
void disp_entry(struct dif *d, FILE *ld) {
  char name[30], addr[29], sw[15], buf[256];
  
  *name = '\0';
  *addr = '\0';
  *sw   = '\0';
   
  fgets(name,30,ld);
  fgets(addr,29,ld);
  fgets(sw,15,ld);
  
  if (sw[strlen(sw)-1] == '\n')
    sw[strlen(sw)-1] = ' ';
    
  if (!name || !addr || !sw) {
    return;  // error
  }
  
  *buf='\0';
  sprintf(buf, "%-29s%-28s%-14s\n",name,addr,sw);
  dd_sendstring(d,buf);
}
   
void add_board(struct dif *d) {
  FILE *fl, *newfl;
  char blfile[40], newblfile[40], name[30], addr[29], sw[15], pmt[30];
  char buf[256];
  int found=0;
  
  sprintf(blfile, "%s/data/bbslist.dat", getenv("DAYDREAM"));
  if (!(fl = fopen(blfile, "rw"))) {
    dd_sendstring(d,"Unable to open bbslist.dat, inform op!\n");
    dd_pause(d);
    dd_close(d);
    return;
  }
  
  sprintf(newblfile, "%s/data/bbslist.new", getenv("DAYDREAM"));
  newfl = fopen(newblfile, "w");
  
  *pmt = '\0';
  *buf = '\0';
  
  sprintf(buf, "\e[36mName of board to add\e[34m:\e[0m ");
  dd_sendstring(d,buf);
  dd_prompt(d,pmt,29,0);

  while (!feof(fl)) {
    *name = '\0';
    *addr = '\0';
    *sw   = '\0';
    
    fgets(name,30,fl);
    fgets(addr,29,fl);
    fgets(sw,15,fl);
        
    if (!strcmp(pmt, name)) { found = 1; break; }    
  }
  
  if (found) {
    dd_sendstring(d, "\e[35mAn entry under that name already exists!\e[0m\n");
    return;
  } else {

    sprintf(buf, "\e[36mPhone number/inet address\e[34m:\e[0m ");
    dd_sendstring(d,buf);
    *addr = '\0';
    dd_prompt(d,addr,28,0);
    
    sprintf(buf, "\e[36mSoftware bbs is running\e[34m:\e[0m ");
    dd_sendstring(d,buf);
    *sw='\0';
    dd_prompt(d,sw,14,0);
    
    fprintf(newfl, "%-29s%-28s%-14s",pmt,addr,sw);
    rewind(fl);
    
    while (!feof(fl)) {
      *name = '\0';
      *addr = '\0';
      *sw   = '\0';
    
      fgets(name,30,fl);
      fgets(addr,29,fl);
      fgets(sw,15,fl);
        
      fprintf(newfl, "%s%s%s",name,addr,sw);    
    }
    
    fflush(newfl);
    fclose(newfl);
    fclose(fl);
    unlink(blfile);
    rename(newblfile, blfile);
  
  }
}

void del_board(struct dif *d) {
  FILE *fl, *newfl;
  char blfile[40], newblfile[40], name[30], addr[29], sw[15], pmt[30];
  char buf[256];
  int found=0;
  
  sprintf(blfile, "%s/data/bbslist.dat", getenv("DAYDREAM"));
  if (!(fl = fopen(blfile, "rw"))) {
    dd_sendstring(d,"Unable to open bbslist.dat, inform op!\n");
    dd_pause(d);
    dd_close(d);
    return;
  }
  
  sprintf(newblfile, "%s/data/bbslist.new", getenv("DAYDREAM"));
  newfl = fopen(newblfile, "w");
  
  *pmt = '\0';
  *buf = '\0';
  
  sprintf(buf, "\e[36mName of board to delete\e[34m:\e[0m ");
  dd_sendstring(d,buf);
  dd_prompt(d,pmt,29,0);

  sprintf(pmt, "%-29s", pmt);    

  while (!feof(fl)) {
    *name = '\0';
    *addr = '\0';
    *sw   = '\0';
    
    fgets(name,30,fl);
    fgets(addr,29,fl);
    fgets(sw,15,fl);
        
    if (strcmp(pmt, name) && strlen(name) > 0)
      fprintf(newfl, "%s%s%s", name, addr, sw);
    else found = 1;
    
  }
    
  if (!found) {
    dd_sendstring(d, "\e[35mNo board name matches input!\e[0m\n");
    dd_pause(d);
  } else {
    dd_sendstring(d, "\e[35mBoard deleted!\e[0m\n");
    dd_pause(d);
  }
    
  fflush(newfl);
  fclose(newfl);
  fclose(fl);
  unlink(blfile);
  rename(newblfile, blfile);
    
}

void disp_boards(struct dif *d) {
  FILE *fl;
  int pagelen=0, i=0;
  char blfile[40];

  *blfile='\0';
  sprintf(blfile, "%s/data/bbslist.dat", getenv("DAYDREAM"));
  if (!(fl = fopen(blfile, "rw"))) {
    dd_sendstring(d,"Unable to open bbslist.dat, inform op!\n");
    dd_pause(d);
    dd_close(d);
    return;
  }

  pagelen = dd_getintval(d, USER_SCREENLENGTH);
 
  dd_sendstring(d, "bbs lister v1.o \e[33m--\e[0m claywar!demonic\n");
  dd_sendstring(d, "\e[36mboard name                   number/address              software\e[0m\n");
  dd_sendstring(d, "\e[34m-----------------------------------------------------------------------\e[0m\n");    
  i=3; // account for header  
  
  while (!feof(fl)) {
    disp_entry(d,fl);
    i++;
    if (i >= pagelen) {
      dd_pause(d);
      if (!feof(fl))
        dd_sendstring(d, "[H[J");
      i = 0;
    }
  }
  
  fclose(fl);
}


void main(int argc, char *argv[]) {
  struct dif *d;
  int what=0,ia=0;
      
  if (argc==1) {
    printf("This is a DayDream door.\n");
    exit(1);
  }
  
  if (argv[2] && !strcmp(argv[2],"interactive"))
    ia=1;
  
  d = dd_initdoor(argv[1]);
  
  if (d == 0) {
    printf("Couldn't find socket!\n");
    exit(1);
  }
  
  dd_changestatus(d, "Using bbs lister...");

  disp_boards(d);
    
  if (ia) {  // Now the menu, add, delete, list again
    int timeleft=0;
    char prompt[256],inp[3];
    
    do {    
      *prompt='\0';
      *inp='\0';
    
      timeleft = dd_getintval(d, USER_TIMELEFT)/60;
    
      sprintf(prompt,"[\e[32m%d\e[0m] \e[36m(\e[34ma\e[36m)\e[0mdd board, \e[36m(\e[34ml\e[36m)\e[0mist again, \e[36m(\e[34md\e[36m)\e[0melete board, \e[36m(\e[34mq\e[36m)\e[0muit\e[36m: \e[0m", timeleft);
      dd_sendstring(d,prompt);
      dd_prompt(d,inp,1,0);
    
      switch (*inp) {
        case 'a':
        case 'A':
          add_board(d);
          break;
        case 'l':
        case 'L':
          disp_boards(d);
          break;
        case 'd':
        case 'D':
          if (dd_getintval(d, USER_SECURITYLEVEL) < 255) {
            dd_sendstring(d, "\e[35mAction not allowed at your security level.\e[0m\n");
            break;
          }            
          del_board(d);
          break;     
      }  
    } while (*inp != 'q' && *inp != 'Q');
  
  }
  
  dd_close(d);

}
  