/*
                 __,,---,__ _    __,,--, __ _
                 |  ___/---,,__,-|  ___//___,,----,______,,---,__ __ _
       _ __ _____|  \_   _  \_   | \\_  __  \_  __   (___)      \ tdmHz
           \\_  __  _|   ____|_ \_/  |  \|   |  \|   | \_   |__//_
            _|  \|  \__  |/  _// |   |_  |  _|   |  _|  _|   |'  _/'' '
     ==== = \\     ___// '  _|   |____/' ' \\____| \\___\__      | = ====
   - -- ---- \____// \_____/__,,-'   \\__,,---'  |____/   \\_,,--' --- -- -
            daydream bbs : quicklogin door v1.o by claywar!demonic                                                                       
    
    So simple, its almost stupid, no?  Well, some people like this sort of
    thing, so why not write it?
*/


#include <stdio.h>
#include "ddlib.h"

void main(int argc, char *argv[]) {
  struct dif *d;
  char buf[80];
  int what=0;
  
  if (argc==1) {
    printf("This is a DayDream door.\n");
    exit(1);
  }
  
  d = dd_initdoor(argv[1]);
  
  if (d == 0) {
    printf("Couldn't find socket!\n");
    exit(1);
  }
  
  dd_changestatus(d, "Using Quicklogin...");
  
  *buf='\0';
  
  sprintf(buf, "\e[33mDo you wish to login quickly? \e[0m(\e[32myes\e[0m/\e[32mNo\e[0m) \e[36m:\e[0m ");
  dd_sendstring(d,buf);
  
  what = dd_hotkey(d, HOT_NOYES);
  
  if (what == 1)  //yes
    dd_typefile(d, "lgquick", TYPE_MAKE|TYPE_WARN);
  else
    dd_typefile(d, "lgnorm", TYPE_MAKE|TYPE_WARN);
  
  dd_close(d);

}
  