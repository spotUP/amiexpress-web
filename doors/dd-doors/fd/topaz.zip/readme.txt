Topaz for PC


Put the files in your \WINDOWS\FONTS folder.

Set your term. app. to use "Topaz New2 12pt.". A restart of the machine might be needed for windows to understand it's got a new font (d0h!).


Have a better one!
Hamlet / Royal / Digital Corruption / Uprough!
