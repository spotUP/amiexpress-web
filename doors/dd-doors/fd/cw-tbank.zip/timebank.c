/*
                 __,,---,__ _    __,,--, __ _
                 |  ___/---,,__,-|  ___//___,,----,______,,---,__ __ _
       _ __ _____|  \_   _  \_   | \\_  __  \_  __   (___)      \ tdmHz
           \\_  __  _|   ____|_ \_/  |  \|   |  \|   | \_   |__//_
            _|  \|  \__  |/  _// |   |_  |  _|   |  _|  _|   |'  _/'' '
     ==== = \\     ___// '  _|   |____/' ' \\____| \\___\__      | = ====
   - -- ---- \____// \_____/__,,-'   \\__,,---'  |____/   \\_,,--' --- -- -
            daydream bbs : timebank door v1.o by claywar!demonic                                                                       
    
   Note: This code was written with a little bit of haste, so there may be
   a few things wrong.  It hasn't broke for me yet, but if it does, email
   me and I'll fix it for the next version (and promptly too.)

*/


#include <stdio.h>
#include "ddlib.h"

char b_prompt(struct dif *d) {
  char buf2[256],res,buf3[256];
  int time=3;
  
  *buf2='\0';
  *buf3='\0';
  time = dd_getintval(d, USER_TIMELEFT);
  
  sprintf(buf3,"[\e[32m%d\e[0m] \e[35mTimebank menu\e[36m: \e[0m",time/60);
  dd_sendstring(d, buf3);
  dd_prompt(d, buf2, 15, 0);
  
  res = *buf2;
  *buf2 = '\0';
  
  return res;
}

void bank_deposit(struct dif *d) {
  char cfgfile[40], buf[10],buf2[50], newfile[40];
  FILE *fl, *newfl;
  int amount=0, timeleft=0, id;
  short int found=0;
  
  timeleft = dd_getintval(d, USER_TIMELEFT);
  timeleft /= 60;
  
  sprintf(cfgfile, "%s/configs/timebank.cfg",getenv("DAYDREAM"));
  fl = fopen(cfgfile, "rw");  
  
  sprintf(newfile, "%s/configs/timebank.cfgnew", getenv("DAYDREAM"));
  newfl = fopen(newfile, "w");
  
  *buf = '\0';
  *buf2 = '\0';
      
  sprintf(buf2, "[\e[32m%d\e[0m] \e[35mAmount to deposit\e[36m: \e[0m", timeleft);
  dd_sendstring(d, buf2);
  dd_prompt(d, buf, 4, 0);
  
  if (buf)
    amount = atoi(buf);
  
  if (amount < 0) {
    dd_sendstring(d, "\e[35mNice try, but no.\e[0m\n");
    dd_pause(d);
    return;
  }
  
  if (amount > timeleft) {
    dd_sendstring(d, "\e[35mYou don't have that much time!\e[0m\n");
    dd_pause(d);
    return;
  }    
   
  id = dd_getintval(d, USER_ACCOUNT_ID);
  
  while (!feof(fl)) {
    int tmpid, tmpval;
    
    fscanf(fl, "%d %d\n", &tmpid, &tmpval);
    if (tmpid == id) {
      fprintf(newfl, "%d %d\n", tmpid, tmpval+amount);
      found = 1;
    } else
      fprintf(newfl, "%d %d\n", tmpid, tmpval);
  }
  
  if (!found)
    fprintf(newfl, "%d %d\n", id, amount);
    
  dd_setintval(d, USER_TIMELEFT, (timeleft - amount)*60);
  
  fflush(newfl);
  fclose(newfl);
  fclose(fl);
  unlink(cfgfile);
  rename(newfile, cfgfile);
    
}

void bank_withdraw(struct dif *d) {
  FILE *fl, *newfl;
  char cfgfile[40],newcfgfile[40], buf[256], numinput[10];
  int amount=0, id, total=0,timeleft;
  
  sprintf(cfgfile, "%s/configs/timebank.cfg", getenv("DAYDREAM"));
  fl = fopen(cfgfile, "r");
  
  sprintf(newcfgfile,"%s/configs/timebank.cfgnew", getenv("DAYDREAM"));
  newfl = fopen(newcfgfile, "w");
  
  id = dd_getintval(d, USER_ACCOUNT_ID);
  timeleft = dd_getintval(d, USER_TIMELEFT);
  
  while (!feof(fl)) {
    int tmpid, tmpval;
    
    fscanf(fl, "%d %d\n", &tmpid, &tmpval);
    if (tmpid == id)
      total = tmpval;
  }
  
  if (total <= 0) {
    dd_sendstring(d,"\e[35mYou don't have any time to withdraw!\e[0m\n");
    dd_pause(d);
    return;
  }
  
  *numinput = '\0';
    
  sprintf(buf, "\e[35mAmount to withdraw \e[0m(Out of \e[32m%d\e[0m)\e[36m:\e[0m ", total);
  dd_sendstring(d, buf);
  dd_prompt(d, numinput, 4, 0);
  
  amount = atoi(numinput);
    
  if (amount > total) {
    dd_sendstring(d,"\e[35mYou don't have that much time!\e[0m\n");
    dd_pause(d);
    return; 
  }

  // Now its time to update the files (oh joy)

  rewind(fl);
  while (!feof(fl)) {
    int tmpid, tmpval;
    
    fscanf(fl, "%d %d\n", &tmpid, &tmpval);
    if (tmpid == id)
      fprintf(newfl, "%d %d\n", tmpid, tmpval-amount);
    else
      fprintf(newfl, "%d %d\n", tmpid, tmpval);
  }
  // We don't have to deal with !found, b/c if they have none, don't add entry
  
  dd_setintval(d, USER_TIMELEFT, timeleft+amount*60);

  fflush(newfl);
  fclose(newfl);
  fclose(fl);
  unlink(cfgfile);
  rename(newcfgfile,cfgfile);
    
}

void main(int argc, char *argv[]) {
  struct dif *d;
  char what;
  
  // Did some idiot try to run this outside of dd?
  if (argc==1) {
    printf("This is a DayDream door.\n");
    exit(1);
  }
  
  // Boot the driver.
  d = dd_initdoor(argv[1]);
  
  // Is the node still there?
  if (d == 0) {
    printf("Couldn't find socket!\n");
    exit(1);
  }
  
  // This changes what shows up in WHO
  dd_changestatus(d, "Using Timebank.....");
  
  // Send our cute lil' message, pause the screen, and then get out.
  
  do {
    dd_typefile(d, "timebank", TYPE_MAKE|TYPE_WARN);
    what = b_prompt(d);
    
    switch (what) {
      case 'd':
      case 'D':
        bank_deposit(d);
        break;
      case 'w':
      case 'W':
        bank_withdraw(d);
        break;
      case 'q':
      case 'Q':
        break;
    }
      
  } while (what != 'q' && what != 'Q');
  
  dd_close(d);

}
  