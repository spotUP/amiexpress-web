/* tLog!n by Whodini for Daydream/Unix.*/

#include <stdio.h>
#include "../lib/ddlib.h"

#define minask 5
#define askstring "[2J[H[1;31mtLog[0m![1;31mn[0;31m: Would you like to TURBO login? [1;30m([0myes[1;30m/[0mNo[1;30m)[0;31m:[0m "
#define ddstatus "tLog!n Door"

struct dif *d;

void main(int argc, char *argv[])
{
	int key;
	int level;
	char buf[128];

	if (argc==1) {
		printf("This program requires DD/Unix!\n");
                exit(1);
        }
        d=dd_initdoor(argv[1]);
        if (d==0) {
                printf("Couldn't find socket!\n");
                exit(1);
        }
	
	dd_changestatus(d,ddstatus);
	
	level=dd_getintval(d, USER_SECURITYLEVEL);
	if (minask<level) {
		dd_sendstring(d,askstring);
		key = dd_hotkey(d, HOT_NOYES);
	}
	else {
		key=2;
	}
	if (key==1) dd_close(d);
	if (key==2) {
		slowlogin();
		dd_close(d);
	}
	if (key==0) exit(1);
}


int slowlogin(void) {
	char buf[128];
	FILE* in_file;
	char command[128];
	int level;
	int security;
	int i;
	int a;
	
	level=dd_getintval(d, USER_SECURITYLEVEL);
	sprintf(buf,"%s/configs/tLogin.cfg",getenv("DAYDREAM"));
	in_file=fopen(buf,"r");
	if (in_file==NULL) {
		dd_sendstring(d,"config file missing!\n");
		dd_close(d);
	}
	
	while(fgets(buf,sizeof(buf),in_file))
	    {	    
		    a = isgraph(buf[0]);
		    if (a!=0 | buf[0]=='#') {
			    a = sscanf(buf,"%d,%[^\n]",&security, command);
			    if (a==2) {	    
				    if (security>level) continue;
				    else proccmd(command);
			    }
			    else {
				    proccmd(buf);
			    }
			    
			    
		    }
	    }
}

int proccmd(char *command) {
	char typefile[128];
	int i;
	
	i = strncasecmp(command,"TF ",3);
	if (i==0) {
		sscanf(command,"TF %s",typefile);
		dd_typefile(d,typefile,TYPE_WARN|TYPE_CONF|TYPE_MAKE);
	}
			    
	i = strncasecmp(command,"CLS",3);
	if (i==0) {
		dd_sendstring(d,"[2J[H");
	}

	i = strncasecmp(command,"PAUSE",5);
	if (i==0) {
		dd_pause(d);
	}
	
	else {
		dd_docmd(d,command);
	}
}
