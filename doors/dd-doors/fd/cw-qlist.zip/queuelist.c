/*
                 __,,---,__ _    __,,--, __ _
                 |  ___/---,,__,-|  ___//___,,----,______,,---,__ __ _
       _ __ _____|  \_   _  \_   | \\_  __  \_  __   (___)      \ tdmHz
           \\_  __  _|   ____|_ \_/  |  \|   |  \|   | \_   |__//_
            _|  \|  \__  |/  _// |   |_  |  _|   |  _|  _|   |'  _/'' '
     ==== = \\     ___// '  _|   |____/' ' \\____| \\___\__      | = ====
   - -- ---- \____// \_____/__,,-'   \\__,,---'  |____/   \\_,,--' --- -- -
           daydream bbs : list file queue door v1.o by claywar!demonic                                                                       
    
    So simple, its almost stupid, no?  Well, some people like this sort of
    thing, so why not write it?
*/

/*
struct FFlag {
  struct Node fhead;
  char   f_filename[256];
  char   f_path[PATH_MAX];
  ULONG  f_size;
  UWORD  f_conf;
  ULONG  f_flags;
};
*/
                                                
#include <stdio.h>
#include <fcntlbits.h>
#include "ddlib.h"

#define SPACESTR	"   "

void die(struct dif *d) {
  dd_close(d);
}

void main(int argc, char *argv[]) {
  struct dif *d;
  char fname[40], buf[256];
  FILE *fl;
  struct FFlag ff;
  int cnt, isctr=0, node;
  
  if (argc==1) {
    printf("This is a DayDream door.\n");
    exit(1);
  }
  
  d = dd_initdoor(argv[1]);
  
  if (d == 0) {
    printf("Couldn't find socket!\n");
    exit(1);
  }
  
  if (argv[2] && !strcmp(argv[2], "center")) isctr=1;
  
  atexit(die,d);
  
  node = atoi(argv[1]);
  
  dd_changestatus(d, "Listing tagged files.");
  
  sprintf(fname, "/tmp/dd/tagfiles.%d",node);
  if (dd_dumpfilestofile(d,fname)) {
    fl = fopen(fname, "r+b");
    if (!fl) 
      exit(1);
  }
  
  *buf = '\0';
  sprintf(buf, "%s\e[36malready tagged files for download\e[0m:\n"
  	       "%s\e[35m##   name                     size             from\e[0m\n"
  	       "%s\e[34m------------------------------------------------------------------------\e[0m\n",
  	       
  	       isctr ? SPACESTR : "",
  	       isctr ? SPACESTR : "",
  	       isctr ? SPACESTR : "");
  	       
  dd_sendstring(d,buf);  	       
  
  cnt=1;
  while (fread(&ff, sizeof(struct FFlag), 1, fl)) {
      *buf = '\0';
      
      sprintf(buf, "%s\e[33m%2d   \e[32m%-24s \e[0m%-16d \e[36m%s\e[0m\n", 
      		isctr ? SPACESTR : "",
                cnt, 
      		ff.f_filename, 
		ff.f_size,
		dd_getconf(ff.f_conf)->CONF_NAME
		);
      
      dd_sendstring(d,buf);
      cnt++;
  }

  exit(1);
}

  