/* 
Rezine's parseme 0.1 -beta- header definition file 
Just contains one prototype for now ;)
*/

char *parse_string(char *, char *, char *, char *);