/*
                 __,,---,__ _    __,,--, __ _
                 |  ___/---,,__,-|  ___//___,,----,______,,---,__ __ _
       _ __ _____|  \_   _  \_   | \\_  __  \_  __   (___)      \ tdmHz
           \\_  __  _|   ____|_ \_/  |  \|   |  \|   | \_   |__//_
            _|  \|  \__  |/  _// |   |_  |  _|   |  _|  _|   |'  _/'' '
     ==== = \\     ___// '  _|   |____/' ' \\____| \\___\__      | = ====
   - -- ---- \____// \_____/__,,-'   \\__,,---'  |____/   \\_,,--' --- -- -
         daydream bbs : message base list door v1.o by claywar!demonic                                                                       
    
    So simple, its almost stupid, no?  Well, some people like this sort of
    thing, so why not write it?
*/


#include <stdio.h>
#include "ddlib.h"

#define SPACESTR	"                   "

void main(int argc, char *argv[]) {
  struct dif *d;
  struct DayDream_Conference *confs;
  struct DayDream_MsgBase *bd;
  struct DayDream_Conference *cd;
  char buf[512];
  int bcnt, isctr=0;

  *buf='\0';    

  if (argc==1) {
    printf("This is a DayDream door.\n");
    exit(1);
  }
  
  d = dd_initdoor(argv[1]);
  
  if (d == 0) {
    printf("Couldn't find socket!\n");
    exit(1);
  }
  
  if (argv[2] && !strcmp(argv[2], "center")) isctr = 1;

  dd_changestatus(d, "listing confs......");
    
  confs = (struct DayDream_Conference *)dd_getconfdata();
  if (!confs) {
    dd_sendstring(d, "\e[36mError opening conference data!\e[0m\n");
    dd_pause(d);
    dd_close(d);
  }
  cd=confs;

  // yeah, the isctr is sloppy, fuck you.

  sprintf(buf, "%s\e[36mavailable conferences\e[34m:\n"
               "%s\e[35m##   name\e[0m\n"
               "%s\e[34m----------------------------------------\e[0m\n",
                 
               isctr ? SPACESTR:"",
               isctr ? SPACESTR:"",
               isctr ? SPACESTR:"");
  
  dd_sendstring(d,buf);
  
  while (cd && cd->CONF_NUMBER && cd->CONF_NUMBER<=64) {
    bcnt = cd->CONF_MSGBASES;
    
    if (dd_isconfaccess(d, cd->CONF_NUMBER)) {
      *buf='\0';
      sprintf(buf, "%s\e[33m%2d   \e[32m%s\e[0m\n",isctr ? SPACESTR:"",cd->CONF_NUMBER, cd->CONF_NAME);
      dd_sendstring(d,buf);
    }
      
    (struct DayDream_Conference *)bd=cd+1;
    
    for (bcnt=cd->CONF_MSGBASES;bcnt;bcnt--,bd++);
    
    (struct DayDream_MsgBase *)cd=bd;
    
  }
  
  
  dd_close(d);

}
  