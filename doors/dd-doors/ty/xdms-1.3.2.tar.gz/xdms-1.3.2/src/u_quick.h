
USHORT Unpack_QUICK(UCHAR *, UCHAR *, USHORT);

extern USHORT quick_text_loc;

