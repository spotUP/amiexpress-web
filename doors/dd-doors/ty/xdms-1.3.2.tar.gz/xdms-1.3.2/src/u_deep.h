

USHORT Unpack_DEEP(UCHAR *, UCHAR *, USHORT);

extern int init_deep_tabs;
extern USHORT deep_text_loc;

