

USHORT Unpack_HEAVY(UCHAR *, UCHAR *, UCHAR, USHORT);

extern USHORT heavy_text_loc;

