
extern UCHAR d_code[], d_len[];

