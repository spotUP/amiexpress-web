#include <stdio.h>
#include <string.h>



int main(int argc, char *argv[]) {
  
  int rc;
  FILE *f;
  char buf[1024];
  char dizbuf[5000];
  char *t;
  int is_diz = 0;

  if (argc < 2) {
	fprintf(stderr, "Syntax; %s <sfv-file>\n\n  Writes file_id.diz to current folder if found in the .sfv file\n\n", argv[0]);
	return 101;
  }

  dizbuf[0] = 0;

  f = fopen(argv[1], "r");
  while (1) {

	t = fgets(buf, 1000, f);

	if (t == NULL)
	  break;

	if (is_diz) {

	  t = strstr(buf, "@END_FILE_ID.DIZ");
	  if (t != NULL)
		is_diz = 0;

	  if (is_diz) {
		if (buf[0] == ';') {
		  rc = 1;
		  if (buf[1] == ' ')
			rc = 2;
		}
		strcat(dizbuf, buf + rc);
	  }
	}
	else {
	  t = strstr(buf, "@BEGIN_FILE_ID.DIZ");
	  if (t != NULL)
		is_diz = 1;
	}
  }

  fclose(f);

  if (strlen(dizbuf) > 10) {
	f = fopen("file_id.diz", "w");
	fprintf(f, "%s", dizbuf);
	fclose(f);
	return 0;
  }
  else {
	// no diz
	return 100;
  }
}
