<html>
<head>
  <style type="text/css">
    FONT {
      font-family:'Topaz New2';
      font-size : 12pt;
    }
  </style>
</head>
<body bgcolor="#000000" text="#C0FFC0" link="#C0FFC0" vlink="#C0FFC0" alink="#C0FFC0">
<?
  // Author: Hamlet / Royal / Digital Corruption / Uprough! / mOODS

  function parseANSI($instr)
  {
    $instr = " " . str_replace(" ", "&nbsp;", $instr);
    $instr = str_replace(chr(92) . chr(110), "<br>", $instr);
    $instr = str_replace("<br><br>", "<br>&nbsp;<br>", $instr);

    $ansi[0]  = "#C0C0C0";
    $ansi[31] = "#800000";
    $ansi[32] = "#008000";
    $ansi[33] = "#808000";
    $ansi[34] = "#000080";
    $ansi[35] = "#800080";
    $ansi[36] = "#008080";
    $ansi[37] = $ansi[0];
    $ansi[41] = "#800000";
    $ansi[42] = "#008000";
    $ansi[43] = "#808000";
    $ansi[44] = "#000080";
    $ansi[45] = "#800080";
    $ansi[46] = "#008080";
    $ansi[47] = $ansi[0];

    $retvbeg = "<table border=0 cellspacing=0 cellpadding=0><tr><td valign=\"top\"><font color=\"" . $ansi[0] . "\">";
    
    $cnt = 1;
    $tds = 1;
    $spos = 0;
    $epos = 0;
    while(true)
    {
      $cnt++;
      
      if ($cnt > 1000)
      {
        $retval = "<br><br><b>Arghh... Endless loop on instr: $instr.</b><br><br>";
        return $retval;
        break;
      }
      
      $spos = strpos($instr, "\e[", $epos);
      
      if (!$spos)
      {
        if (!$epos)
          $retval.= $instr;
        else
          $retval.= substr($instr, ($epos+1), strlen($instr));

        break;
      }

      if (!$epos)
        $epos = -1;
        
      $retval.= substr($instr, ($epos+1), ($spos-$epos)-1);
      $spos = $spos+3;
      $epos = strpos($instr, "m", $spos);

      if (($epos > strpos($instr, "\e[", $spos)) && (strpos($instr, "\e[", $spos) > 0))
        $epos = 0;

      $h = 0;
      if (!$epos)
      {
        $epos = strpos($instr, "H", $spos);
        $h = 1;
      }

      if (!$epos)
      {
        $epos = strpos($instr, "D", $spos);
        $h = 1;
      }

      if (!$epos)
      {
        $retval = $instr;
        return $retval;
        break;
      }
      
      $val = substr($instr, $spos, ($epos-$spos));
//if (strstr($instr, "rmpromptstr:"))
//  echo "[spos=$spos][epos-spos=" . ($epos-$spos) . "][val=$val][h=" . $h . "]";

      if (!$h)
      {
        $sempos = strpos($val, ";");
        
        if ($sempos)
          $val = substr($val, $sempos+1, strlen($val));

        if ($val != 0)
        {
          if ($val < 40)
            $retval.= "</font><font color=\"" . $ansi[$val] . "\">";
          else
          {
            $retval.= "</td><td valign=\"top\" bgcolor=\"" . $ansi[$val] . "\">";
            $tds++;
          }
        }
        else
        {
          $retval.= "</td><td valign=\"top\"><font color=\"" . $ansi[0] . "\">";
          $tds++;
        }
      }
    }
    
    $retval = $retvbeg . substr($retval, 1, strlen($retval)) . "</font>";

    if (strstr($instr, "<br>"))
      $retval.= "</tr><tr><td colspan=$tds valign=\"top\"><img src=\"cursor.gif\"></td></tr></table>";
    else
      $retval.= "<img src=\"cursor.gif\"></td></tr></table>";
    
    return $retval;
  }

  $orgfile = "strings.org";
  $newfile = "strings.001";

  $fd = fopen($orgfile, "r");

  if (!$fd)
  {
    echo "<b>Fatal Error:</b> Could not open .org file ($orgfile).";
    fclose($fd);
    exit;
  }

  $orgtext = fread($fd, filesize($orgfile));
  fclose($fd);

  
  $fd = fopen($newfile, "r");

  if (!$fd)
  {
    echo "<b>Fatal Error:</b> Could not open .001 file ($newfile).";
    fclose($fd);
    exit;
  }

  $newtext = fread($fd, filesize($newfile));
  fclose($fd);

  $orgtext = str_replace("\r\n", "\n", $orgtext);
  $orgtext = str_replace("\n\r", "\n", $orgtext);
  $orgtext = str_replace(chr(27), "\e", $orgtext);
  $newtext = str_replace("\r\n", "\n", $newtext);
  $newtext = str_replace("\n\r", "\n", $newtext);
  $newtext = str_replace(chr(27), "\e", $newtext);

  if ($action == "E")
  {
    $newline = str_replace(chr(92) . chr(92), chr(92), $newline);
    $oldline = str_replace(chr(92) . chr(92), chr(92), $oldline);
    $newline = str_replace("\'", "'", $newline);
    $oldline = str_replace("\'", "'", $oldline);

    //echo $oldline . "<br>" . $newline;
    $newtext = str_replace("$head:$oldline", "$head:$newline", $newtext);
    $fd = fopen($newfile, "w");

    if (!$fd)
    {
      echo "<b>Fatal Error:</b> Could not open .001 file ($newfile).";
      fclose($fd);
      exit;
    }
    else
      fwrite($fd, $newtext);
      
    fclose($fd);
  }

  $spos = 0;
  $epos = 0;
  $cnt = 1;
  while (true)
  {
    $epos = strpos($orgtext, "\n", $spos);
    $colon = strpos($orgtext, ":", $spos);

    if ((!$epos) || ($cnt > 50000) || (!$colon))
      break;

    $orglines[$cnt] = substr($orgtext, $colon+1, ($epos-$colon)-1);
    $heads[$cnt] = substr($orgtext, $spos, ($colon-$spos));
    
    $spos = $epos+1;
    $cnt++;
  }

  $spos = 0;
  $epos = 0;
  $cnt = 1;
  while (true)
  {
    $epos = strpos($newtext, "\n", $spos);
    $colon = strpos($newtext, ":", $spos);

    if ((!$epos) || ($cnt > 50000) || (!$colon))
      break;

    $newlines[$cnt] = substr($newtext, $colon+1, ($epos-$colon)-1);

    $spos = $epos+1;
    $cnt++;
  }

  $cnt = 1;
  while (($newlines[$cnt]) && ($action != "V"))
  {
    echo "<font color=\"#FFFFFF\"><a name=\"$cnt\">[$cnt]</a> [" . $heads[$cnt] . "] </font> " .
         "<a href=\"dd.php?id=$cnt&action=V\"><font color=\"#C0FFC0\">[Edit]</font></a>" . parseANSI($newlines[$cnt]) . "<br>";
    $cnt++;
  }
  
  if ($action == "V")
  {
    echo "<u>Original Line:</u><br>" .
         parseANSI($orglines[$id]) . "<br>" .
         "<u>Current Line:</u><br>" .
         parseANSI($newlines[$id]) . "<br><br>" .
         "<form action=\"dd.php#$id\" method=\"POST\">" .
         "<textarea name=\"newline\" cols=70 rows=10>" .
         $newlines[$id] . "</textarea>" .
         "<input type=\"hidden\" name=\"id\" value=\"$id\">" .
         "<input type=\"hidden\" name=\"oldline\" value=\"" . $newlines[$id] . "\">" .
         "<input type=\"hidden\" name=\"head\" value=\"" . $heads[$id] . "\">" .
         "<input type=\"hidden\" name=\"action\" value=\"E\"><br><br>" .
         "<input type=\"submit\" value=\"Edit\"></form><br><br>" .
         "<font color=\"#C0C0C0\">0m</font> " .
         "<font color=\"#800000\">31m</font> " .
         "<font color=\"#008000\">32m</font> " .
         "<font color=\"#808000\">33m</font> " .
         "<font color=\"#000080\">34m</font> " .
         "<font color=\"#800080\">35m</font> " .
         "<font color=\"#008080\">36m</font> " .
         "<font color=\"#C0C0C0\">37m</font> " .
         "<table border=0><tr>" .
         "<td bgcolor=\"#800000\"> 41 </td>" .
         "<td bgcolor=\"#008000\"> 42 </td>" .
         "<td bgcolor=\"#808000\"> 43 </td>" .
         "<td bgcolor=\"#000080\"> 44 </td>" .
         "<td bgcolor=\"#800080\"> 45 </td>" .
         "<td bgcolor=\"#008080\"> 46 </td>" .
         "<td bgcolor=\"#C0C0C0\"> 47 </td></tr></table><br><br><a href=\"dd.php#$id\">Back</a>";
  }
?>
</body>
</html>
