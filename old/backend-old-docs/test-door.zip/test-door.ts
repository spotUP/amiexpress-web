// Test Door
// Auto-generated test door for upload testing

import { Socket } from 'socket.io';

export async function executeDoor(socket: Socket): Promise<void> {
  socket.emit('ansi-output', '\x1b[1;36m-= TEST DOOR =-\x1b[0m\r\n\r\n');
  socket.emit('ansi-output', 'This is a test door created by the upload test script.\r\n\r\n');
  socket.emit('ansi-output', 'Upload functionality is working correctly!\r\n\r\n');
  socket.emit('ansi-output', 'Press any key to exit...\r\n');

  // Wait for key press
  await new Promise((resolve) => {
    const handler = () => {
      socket.off('terminal-input', handler);
      resolve();
    };
    socket.on('terminal-input', handler);
  });

  socket.emit('ansi-output', '\r\nReturning to BBS...\r\n');
}